var msgContainer = document.querySelector(".message")
var height = msgContainer.clientHeight;
msgContainer.scrollTo(height)